(() => {
  if (window.__ytonly) return;
  window.__ytonly = true;

  /* ===== 1. ANUNCIOS: eliminar datos de ads antes de que el reproductor los lea ===== */
  const KEYS = ['adPlacements', 'playerAds', 'adSlots'];
  const prune = (o) => {
    if (!o || typeof o !== 'object') return o;
    for (const k of KEYS) if (k in o) delete o[k];
    if (o.playerResponse) prune(o.playerResponse);
    return o;
  };

  let ipr;
  try {
    Object.defineProperty(window, 'ytInitialPlayerResponse', {
      configurable: true, get: () => ipr, set: (v) => { ipr = prune(v); }
    });
  } catch (e) {}

  const _parse = JSON.parse;
  JSON.parse = function () {
    const r = _parse.apply(this, arguments);
    try { if (r && typeof r === 'object' && (r.adPlacements || r.playerAds || r.adSlots || r.playerResponse)) prune(r); } catch (e) {}
    return r;
  };

  const _fetch = window.fetch;
  window.fetch = async function (input, init) {
    const res = await _fetch.call(this, input, init);
    try {
      const url = typeof input === 'string' ? input : ((input && input.url) || '');
      if (/\/youtubei\/v1\/(player|get_watch)/.test(url)) {
        const data = prune(await res.clone().json());
        return new Response(JSON.stringify(data), { status: res.status, statusText: res.statusText, headers: res.headers });
      }
    } catch (e) {}
    return res;
  };

  /* ===== 2. CSS: ocultar banners/slots de anuncios + modo PiP ===== */
  const css = `
    #masthead-ad, #player-ads, .video-ads, .ytp-ad-module, .ytp-ad-overlay-container, .ytp-ad-image-overlay,
    ytm-promoted-sparkles-web-renderer, ytm-promoted-video-renderer, ytm-companion-slot, ytm-ad-slot-renderer,
    ad-slot-renderer, ytm-statement-banner-renderer, ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer,
    ytd-display-ad-renderer, ytd-banner-promo-renderer, ytd-statement-banner-renderer,
    ytm-rich-item-renderer:has(ad-slot-renderer), ytm-item-section-renderer:has(ad-slot-renderer)
    { display: none !important; }
    html.ytonly-pip, html.ytonly-pip body { overflow: hidden !important; background: #000 !important; }
    html.ytonly-pip body * { visibility: hidden !important; }
    html.ytonly-pip video { visibility: visible !important; position: fixed !important; top: 0 !important; left: 0 !important;
      width: 100vw !important; height: 100vh !important; z-index: 2147483647 !important; object-fit: contain !important; background: #000 !important; }
  `;
  const addStyle = () => {
    if (document.getElementById('__ytonly')) return;
    const s = document.createElement('style');
    s.id = '__ytonly';
    s.textContent = css;
    (document.head || document.documentElement).appendChild(s);
  };
  if (document.documentElement) addStyle();
  else new MutationObserver((m, o) => { if (document.documentElement) { o.disconnect(); addStyle(); } }).observe(document, { childList: true });

  window.__ytonlyPip = (on) => document.documentElement.classList.toggle('ytonly-pip', !!on);

  /* ===== 3. Red de seguridad: si se cuela un anuncio, silenciar y saltar al final ===== */
  let adMuted = false, prevMuted = false;
  setInterval(() => {
    const p = document.querySelector('.html5-video-player');
    const v = document.querySelector('video');
    const showing = !!(p && p.classList.contains('ad-showing'));
    if (showing && v) {
      if (!adMuted) { adMuted = true; prevMuted = v.muted; v.muted = true; }
      if (isFinite(v.duration) && v.duration > 0) v.currentTime = v.duration;
    } else if (adMuted && v) {
      v.muted = prevMuted; adMuted = false;
    }
    document.querySelectorAll(
      '.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-skip-button-container button, .ytp-ad-overlay-close-button'
    ).forEach((b) => b.click());
  }, 250);

  /* ===== 4. Segundo plano: la página cree que siempre está visible ===== */
  const def = (o, p, g) => { try { Object.defineProperty(o, p, { configurable: true, get: g }); } catch (e) {} };
  def(document, 'hidden', () => false);
  def(document, 'visibilityState', () => 'visible');
  def(document, 'webkitHidden', () => false);
  def(document, 'webkitVisibilityState', () => 'visible');
  const stop = (e) => e.stopImmediatePropagation();
  document.addEventListener('visibilitychange', stop, true);
  document.addEventListener('webkitvisibilitychange', stop, true);
  window.addEventListener('blur', stop, true);
  document.hasFocus = () => true;

  /* ===== 5. Avisar a Android si hay video reproduciéndose (para PiP y servicio) ===== */
  const report = () => {
    try {
      const v = document.querySelector('video');
      if (window.NativeBridge) NativeBridge.playState(!!(v && !v.paused && !v.ended));
    } catch (e) {}
  };
  ['play', 'playing', 'pause', 'ended', 'emptied'].forEach((ev) => document.addEventListener(ev, report, true));
})();
