package com.example.ytonly

import android.Manifest
import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

object Config {
    const val HOME = "https://m.youtube.com/"
    const val KEEP_LOGIN = true     // false = al cerrar también se borra la sesión de Google
    const val PIP_ON_HOME = true    // false = al pulsar Inicio solo sigue el audio, sin ventana flotante
}

class MainActivity : ComponentActivity() {

    companion object { private var cold = true }

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    @Volatile private var playing = false
    private var script = ""

    private val loginHosts = setOf("accounts.google.com", "consent.google.com", "myaccount.google.com")
    private val adHosts = listOf("doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.", "imasdk.googleapis.com")
    private val adPaths = listOf("/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_info")

    private fun isAllowed(u: Uri): Boolean {
        if (u.scheme != "https") return false
        val h = u.host ?: return false
        return h == "youtu.be" || h == "youtube.com" || h.endsWith(".youtube.com") || h in loginHosts
    }

    private fun isAd(u: Uri): Boolean {
        val h = u.host ?: return false
        if (adHosts.any { h.contains(it) }) return true
        val p = u.path ?: return false
        return h.endsWith("youtube.com") && adPaths.any { p.contains(it) }
    }

    inner class Bridge {
        @JavascriptInterface
        fun playState(p: Boolean) {
            playing = p
            PlaybackService.instance?.setPlaying(p)
        }
    }

    private val client = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
            !isAllowed(request.url)   // true = bloquear navegación fuera de YouTube

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
            if (isAd(request.url))
                WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            else null

        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            // Respaldo si el WebView no soporta inyección en document-start
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                view.evaluateJavascript(script, null)
            }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            CookieManager.getInstance().flush()
        }
    }

    private val chrome = object : WebChromeClient() {
        override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
            if (customView != null) { callback.onCustomViewHidden(); return }
            customView = view
            customCallback = callback
            root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            web.visibility = View.INVISIBLE
            setBars(false)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }

        override fun onHideCustomView() {
            customView?.let { root.removeView(it) }
            customView = null
            customCallback?.onCustomViewHidden()
            customCallback = null
            web.visibility = View.VISIBLE
            setBars(true)
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    private fun setBars(show: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (show) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        script = assets.open("yt.js").bufferedReader().use { it.readText() }

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this)
        root.addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(false)
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            // Quita las marcas de WebView para que el login de Google no lo rechace
            userAgentString = userAgentString.replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+ "), "")
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false) // mantiene el audio vivo en segundo plano
        web.addJavascriptInterface(Bridge(), "NativeBridge")
        web.webViewClient = client
        web.webChromeClient = chrome

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, script, setOf("https://*.youtube.com"))
        }

        // Arranque en frío = sesión nueva: sin historial ni caché de la sesión anterior
        if (cold) {
            cold = false
            web.clearCache(true)
            web.clearHistory()
            if (Config.KEEP_LOGIN) CookieManager.getInstance().removeSessionCookies(null)
            else CookieManager.getInstance().removeAllCookies(null)
        }

        try { startService(Intent(this, PlaybackService::class.java)) } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> chrome.onHideCustomView()
                    web.canGoBack() -> web.goBack()
                    else -> moveTaskToBack(true)
                }
            }
        })

        val start = intent?.data?.takeIf { isAllowed(it) }?.toString() ?: Config.HOME
        web.loadUrl(start)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.takeIf { isAllowed(it) }?.let { web.loadUrl(it.toString()) }
    }

    // ---- Ventana flotante ----
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Config.PIP_ON_HOME && playing && Build.VERSION.SDK_INT >= 26) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            } catch (_: Exception) {}
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        // En PiP se muestra solo el <video>, sin el resto de la página
        web.evaluateJavascript("window.__ytonlyPip && window.__ytonlyPip($isInPictureInPictureMode)", null)
    }

    // ---- Segundo plano: NO se llama a web.onPause() ----
    override fun onStop() {
        super.onStop()
        web.resumeTimers()
    }

    override fun onDestroy() {
        root.removeAllViews()
        web.destroy()
        super.onDestroy()
    }
}
