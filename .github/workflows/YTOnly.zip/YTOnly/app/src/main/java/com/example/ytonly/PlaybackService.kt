package com.example.ytonly

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import androidx.core.app.ServiceCompat

class PlaybackService : Service() {

    companion object {
        @Volatile var instance: PlaybackService? = null
        private const val CH = "yt_playback"
        private const val ID = 1
    }

    private val main = Handler(Looper.getMainLooper())
    private var wl: PowerManager.WakeLock? = null
    private var foreground = false

    override fun onCreate() {
        super.onCreate()
        instance = this
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Reproducción", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY

    private fun notification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("YouTube")
            .setContentText("Reproduciendo en segundo plano")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    fun setPlaying(p: Boolean) {
        main.post {
            if (p && !foreground) {
                try {
                    ServiceCompat.startForeground(this, ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                    foreground = true
                } catch (_: Exception) {}
                val pm = getSystemService(PowerManager::class.java)
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ytonly:play").apply { acquire(6 * 60 * 60 * 1000L) }
            } else if (!p && foreground) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                foreground = false
                wl?.takeIf { it.isHeld }?.release()
            }
        }
    }

    /** Se dispara al quitar la app de Recientes: limpia todo y mata el proceso. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        wipe()
        wl?.takeIf { it.isHeld }?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        main.postDelayed({ Process.killProcess(Process.myPid()) }, 1200)
        super.onTaskRemoved(rootIntent)
    }

    private fun wipe() {
        try {
            WebView(applicationContext).apply { clearCache(true); clearHistory(); destroy() }
        } catch (_: Throwable) {}
        try { WebStorage.getInstance().deleteAllData() } catch (_: Throwable) {}
        val cm = CookieManager.getInstance()
        if (Config.KEEP_LOGIN) cm.removeSessionCookies(null) else cm.removeAllCookies(null)
        cm.flush()
    }

    override fun onDestroy() {
        instance = null
        wl?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }
}
