# YTOnly
App Android (WebView/Chromium) solo-YouTube: sin pestañas ni barra, PiP, segundo plano, adblock, limpieza al cerrar.

## Compilar sin PC
1. Sube esta carpeta a un repo de GitHub (app o web).
2. Pestaña Actions > build-apk > Run workflow.
3. Descarga `YTOnly-apk` de Artifacts, descomprime e instala `app-debug.apk`.

## Compilar con Android Studio
Abrir la carpeta y Run (JDK 17).

## Ajustes (MainActivity.kt > object Config)
- KEEP_LOGIN: conservar sesión de Google al cerrar (true) o borrarla (false)
- PIP_ON_HOME: ventana flotante al pulsar Inicio

## Samsung
Ajustes > Batería > Sin restricciones para esta app, para que el audio no se corte con la pantalla apagada.
